<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '059e58d45956c3fa72943c599aa0fd17',
      'native_key' => 'core',
      'filename' => 'modNamespace/b7f96fabf6ee9e0571a3a320aa34a8c7.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '6f4070788265657c6577b3d99151a77f',
      'native_key' => 1,
      'filename' => 'modWorkspace/8cf9c7802aa420be585d6beaa546a405.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '075688c1a84bb27229414a7ea45515ca',
      'native_key' => 1,
      'filename' => 'modTransportProvider/06450335e384bd779e61e66132161104.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'dcefe3863c51487f6f44756e46e70ede',
      'native_key' => 'topnav',
      'filename' => 'modMenu/485433731b36e8eefa328921ad8d3d4f.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '16c52a6c3c32c91e8ecc184ed9f4a6e9',
      'native_key' => 'usernav',
      'filename' => 'modMenu/bb4b166f28e0f9a95442ebbac84d0697.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'a6831ad2e507353c21fe7871f3846963',
      'native_key' => 1,
      'filename' => 'modContentType/0cb9d7a8c6a6e8c8f3c9141c9146d132.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'fdde112e5f1fbaf327dec60bd109fbac',
      'native_key' => 2,
      'filename' => 'modContentType/2a47251982163209ce71c39143a1adb3.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '83257d7bbb1c74d9271f955038d7e178',
      'native_key' => 3,
      'filename' => 'modContentType/84d3c8012daa3d25ff2d1c496d5040a0.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'fbe903f6023dc8fc5cfee6e7b72faceb',
      'native_key' => 4,
      'filename' => 'modContentType/9f8559185b42a4ad34641ef7b7547573.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '0aaf2e011bb7c6c5b6744062948050d6',
      'native_key' => 5,
      'filename' => 'modContentType/bd9d3cd3a7bfeb2b1d6100ccd1a16988.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '610e019ea58efe53e26ce92aa9cefb44',
      'native_key' => 6,
      'filename' => 'modContentType/ba42a22691fafcab18a849dbc5e02803.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'd21163f0c01d092679573d8c94e948b0',
      'native_key' => 7,
      'filename' => 'modContentType/4bab900196e80947eca7d9fc4ca56215.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'a7b809648ebffa902a09a990f6fd9fd2',
      'native_key' => 8,
      'filename' => 'modContentType/9a68044cf30e880a80450a129467b8d6.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'd28b7a068696721f14f674579103bb15',
      'native_key' => NULL,
      'filename' => 'modClassMap/d906be5fa10d9a0d5964b83b305b9f3b.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'f28e1ad56d0a34aea21313553bf61d72',
      'native_key' => NULL,
      'filename' => 'modClassMap/ce574a07f3592723c6afb4c631bf5b99.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '1de728690b2e368120d2518d64a7fdea',
      'native_key' => NULL,
      'filename' => 'modClassMap/e324a567de49f4ce52249900baccce3e.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '27596c23da3e0bc94467302d5c006e17',
      'native_key' => NULL,
      'filename' => 'modClassMap/af891efbca0f182cdb8191fb865cc600.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'c6526d273aeebeab667a7029955f8691',
      'native_key' => NULL,
      'filename' => 'modClassMap/580e59602b8074cde49e5e64bca20956.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'b8a049565ac7c3c2b6c4d64e59a6d37a',
      'native_key' => NULL,
      'filename' => 'modClassMap/44127e26d56067cbdd80bf1a7c93dd2e.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '8ee3499c754daad7195d69a69fa9e2cb',
      'native_key' => NULL,
      'filename' => 'modClassMap/aea21f288b69c9ddb9fc3d5fa2bfa634.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '59eeb547c1233372e115c60fa4f66d24',
      'native_key' => NULL,
      'filename' => 'modClassMap/6774193814825f965e0bf58d235e6542.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'a3ec01202b45b008c2bc28858bd90aeb',
      'native_key' => NULL,
      'filename' => 'modClassMap/6f237174762c64d094f11c07a3fb3628.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a25d58ce652243c0b375364fb34e69e7',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/0672560b3befc1c576dce122b8ae9af6.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '93e478ff43b2ef21fed046c4a85cee67',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/d23f924de040ea8519518d67d74e80b2.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd5ff3a52c40d206988c1684c8e799b48',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/f39ec449068d6ec14041d76c38125c65.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '542adb656d6e18932f01faa9acc3c919',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/44211b89ff2544fc18784e4cc97c2cbb.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f75039632f2c1b0bd93ae7f689eb6b97',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/4e6e0abf0f5c243c521ae0f920c79613.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '31adc5b6312022d24a977a6e9f8e5577',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/b6a24a69a4315d49c540cfa26e65c1bd.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f9a9a1f831f8de13b3615ece34705df',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/525eba6783807be0ecd524cab5bd5e8a.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0fb004c546d5ed63d5622f44a4fd2cc7',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/a63e69a460d7b39c8de5e8602d72200f.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a1792f2a3f77378efb2715e60b626af5',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/560ee369458056e5d2b442fb9029aed3.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6de0141c9c25b939da3dcdae06f1a7d0',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/b70c90c4a644dec921f70b24e05ae8cc.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0109276b602848f206d9d25f737c4bee',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/6b4e70fe25eba5a232dce5f5bc260fbe.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e4ac7767d6b3f6b4c1009018240e20b',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/74f19a5977b413e69ce27fccdac72540.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac7c5b7021305087445b6c043557d06f',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/f9299718f8a2a7674c33880724e01f94.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f601e69ff6bfcfaabe4a3efcb6239e1f',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/48abcf74c2b76bd3867b9d8ab515c561.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd13f2aa5b1ef2e112ac8849f09c86a13',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/c1212d62babcb4c10b47ec6982649896.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8ab79a759c8afcd185f9ead676814781',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/edbede2b2fe1037830ec911432766ca8.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a80bc531305576e8774fc6cb9abcb815',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/d6b8125251cd33a8a3c066af6ee46a5f.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6da87df5f3f030d4705a9e4a36b9d2f6',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/573a8019d62b2fe5a6b128a0f791ca59.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd220684c88595aaaae6d95e4a1d23fd8',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/39009566202e99e13e418fbc4ed2b839.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac9dd41efcb5d5cf9787d25078c903ab',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/be28401721fa97fd8b996b62474021c5.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1308773ea195528ea653fbe75fce52f0',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/ab55661161c7be2ad77f2efef6d9c856.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '39fa5b5b61a68b88f1deea6b5f8b03ac',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/5906b01c5f519f01e848394acc4f70ea.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f04b75e7c1683a5e96462707b007c828',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/d7801c4d92d67eb3ce892efb88087fc8.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c868d1d63d370554f386d68f00271ec9',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/4ef39b3a73597524c18b4929a5b9536c.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af41961a9e80f5fca92cda94fe4d470c',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/43b6b54e119e6b9c76fb3e4746a5e26e.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a6c068a9024f03149076c02dc45b1e2c',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/f88aff8727050eb65dad9c142b602324.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b91df4644c012abc148b228ba272d599',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/3403fe2ec61ee563924c2ebcdd8540e1.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd9e6c5dd33e358bc1ad6e743414f6068',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/10848df1577457c43f6ca912cd8ce7bb.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '68a34b40b21a00332e684c859f3ca85f',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/7c493c3894cd32860b3024e47e840309.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '07c95ddf786b0291b0f2f6a80fa5c594',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/a764ef1910d6b37b20bfa01e3efb3d3e.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4911e75ceea1cb0be1b72cc52c0dc8c4',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/85427ea472b1c74ea2bb260e2612bd6f.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf4479f59380a081ceff6118a1d8b125',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/64004ce3911896e448a8c662dab03bbf.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'acdb65078a1271bb457563ed4792a0bd',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/86106f6821920c00f0c6873b75033e2d.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '792a1760502d44af8f0ef02744dc89d6',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/c26532845c3b0a84842302275a68f683.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5139c084357ecec6f9842df48a49cc6a',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/eaf3ab3fb7fbfb8fc81e01d75f076cdb.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd05ada98a3fda6bb604b25ad7e2e3219',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/e695c8d8bd84f492fa3a0afe6222658c.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e917d4cb33536ace4fbca34906200a2',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/9f9a2ffbf19d106b0845d04a5191af75.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c73816aaf94681725a088258f8ae484',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/e89a207c33f83b6d6aef75e1e96534df.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0389f4eb0204aee93b3868f0571139f9',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/e4a48658d251c1bd97df3324ddd0cb15.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '613c5215aab7584e486898b4d0e87130',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/6c89d65981dffa7603b7e31e8f2b9270.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1470501eaba4c035af90cfb83012707e',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/8d094f4e72c509b1734378ca41857315.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cce36a2f08913160797a9f466a6a60dd',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/3dd1899b6be7f22e420453a48614e6f5.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a23378c34ee972ff95ca5bc09e5bc8e6',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/45bc2bbf41a1340fa5ef0794e8be94d7.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '274c04ae8c2413022c752b1251e32660',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/017b17ddb08de53e5fe7f4f6e5ea32ee.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a8372cc526d24bb73f684cd4279c5150',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/89752e8dd1c647b8eeda8578765e3554.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '17f34df56a627f1957d511670dc6c7aa',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/6949338dd338b1c19ec150906898ea1e.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f45d50a6527f98b95c62262291eeed1a',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/04c6cab97ccd47570558f6fe043ecc98.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f10553ad4c3eb771fd129d1b7a6b6749',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/ce74aa1050a15a1a443a04e67566f453.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '68b483317858f71526c220f790080e1e',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/45b2abcc7f4fae55f6ccdc858c07894a.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ae356ad4193eaa1eb4736f38a812ea9f',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/85e7f0d3efe541d2304b8ad3087fbcc6.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2685bbd3d48bf5c97c7846e7b405ac34',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'modEvent/25148c6b12a5529b16a70a118c02c0e7.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0049c4a2ece2f6595e5729e128fb12dc',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'modEvent/6881b7916fc0a9353c9561e744c576b8.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '77f2a32bcadca3be1d66dbc8b7ae7ebc',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'modEvent/f797e9b2fad9286cc4b6f2fc41ce9340.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd26da15bbd7b8e9668831f8fbf9b548d',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'modEvent/a601cd87f234ab0a21b9a766c416a100.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9fb58948c15f3a39e6b08e3541f1f875',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/f855000dcbbd0a20b3c42b472564e9c0.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3d288775e2d62e02e0b40cb22e23395a',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/4d7b76d8289bd2aac76fa34a2cc538ef.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '77e39b5d9c790cd8fad16da38e184647',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/ea6b05375ae148ae29ffa4e737eb3adf.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2b7afcc889067897f067f588ac6dea45',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/85cb5c289782d5a8aca3d9de1073a5e9.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2b2b42ea2d67549874ec46f0eb09e2e3',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/9dd5e7554ed65759f54dce4755a6a074.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9100c512a9a4f5cde3d960b8700b7680',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/d6cd2b0ec25944fa5fdbdefb08026b2a.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bf2cecd9b8d6e46877d41d4332a08f7e',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/53aad498abaa8c17afe0c890131b07cd.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0a6b81e0631d25aae8a314a407f2b8e0',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/f9bf2a93814480b95273b8356167ccb0.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a8ee7c45a4dfa7b5526555a65a2f9594',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/8944f7a677e4a43eae405cdf998872d8.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c6670543df006cb15df3f024fbdd002',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/9e6c125297d1a25ad19e8c98afb7f4f7.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e70d8748944690a7a13c4fd9a4ef85a5',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/087f35688afc1c819acf28fb47614407.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dec436201baa88550af061de9c1f18a0',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/7bb2141eb169ba427ec323b3a6f450ea.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7dec0fa3c15664772fcf117913b9e0a5',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/ae8ad28546e02df2b209eb01baacd5ba.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '66f724c03f526fe71eb70fd0f45074ad',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/373e0b3ccdd439cca15ff9009e3f4c9e.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e9b54e38c8dda256fe5440cc5560a929',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/7f80ef96b4f850ee6911228e30cc9353.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '36626cd7820082b88fd2de71e0cfc28f',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/5bcd4caea47749a9e121e1e0c4a37e32.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '14eb20efe4edc7960289de572ac31dda',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/8c060b67f621138be86a5ae6bb533fcc.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc6c8f42f2150e44bc75cb15cdd267fa',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/b1827087fc878426b5cdcf2a0e05c5f3.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5a0139b709e175e8f618445702e14a20',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/5fcc56b40c0cea43280146f924262edd.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '73820b54f2918fa902b800a258baddc6',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/239a58875f1c22c882495a2ee4d809af.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '167833de5312530e626321a50e2a624b',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/5c70a7981523637027ce44c2f0bc1b9d.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5605a472f2e23ef3e552973fe63bcea7',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'modEvent/2b794a70957045eb358127794a2c0ee0.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e8800b4a94b6defe1b9ad4dfc44ecc1e',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/d3b5fedcf02b247ef45df38ed9e9ab4d.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e0143612dcc346a57d9568d34a0b8841',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/dc51e25d205c6933b3dd3b53ac1e6759.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a48d5cf7997b11df481397a9fb5005c',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/c8bc0aa11a507fdce577d1619a1bd27a.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '07755746d32f25e664e48b94858d9ed5',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/ca7dbffef1d8f13b1ae3dae317b31e17.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8880609a038b5d6fd5114494d21502a2',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/47fc4f35e3c3b6063f9d5450ec398f0c.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e8e223d8e6f193e529785fda7fdd896',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/5f92d9f308a74fc4648d595807289bb5.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9662590ec39806743b2a47fe9c5b92ca',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/a0c5ac5b26e3674e51c761400bf52b65.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2cc8e0bf2f935a2e1092ba455b0641cd',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/112aac0dc35ee80082399f7ac4a6ddc5.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ddc91c86a07f3456fd2a184f64c464fb',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/4fef75569fdfed0898f62362a2e0b087.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c9a0b67687b3de48f0eda40690396637',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/42f6329e9d27495b39c4b11b1db9710e.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a31fb11cde4b3cf22cb04fcfe527a65b',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/0bdf4ee8d9f0db5ce6c44198dfa00840.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c81a4caaf13877e772be819a69ed1863',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/6405e58b562553faba2d5dfbab546985.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '40adbcece9e194f5ab2186d9973703dc',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/1cf576c2102943f139cd8196e010ec37.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cb237068f8078a8705557fc8524486ac',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/f4e3d0afa888421fc3bba76c8f71e9a3.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5893cb32428f45530111850bd0a76266',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/cd9ac38a38ba2b94521233552540a08d.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7214e92db95e7a99a5896654d36984fb',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/b9604cc0f66de00da144ab4f6e54133f.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '85b543f9ffa95e9ce0a3c53a797061b2',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/2629de2e1bfb21725172ad48fd33a39c.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e99513451b5431d6e3466309c99c7eb6',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/70d1433912a8794eb84038f0df418bee.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e944eb5a35ec86dbfe165cbe70b4672',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/ba65a94ad9f73c0396bd5005a9c9ee3e.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a4beed757f7c0d2e110184c2c20b5dcf',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/eefc18479ceea0331cbbeafd08aea7ac.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '593565541eee0ce271bb3bc9b2b1a00e',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/1c1275e382d5b1b543dece8de4f2b012.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a054ddd5b024a5f5d4ac9ada462a4345',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/a9e30df9bd3e1dc8b9345bce540f5e2e.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9b5a886dc732781f9df9ca0a994dd5f2',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/73a5dcf07d73651d9512be6db333c3ec.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e780ca0ba8bb7fc2e10d31c0f09469c5',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/eaa708886150d52ddfcc17577a3480aa.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7686e645b3cbe021d557898e8e359b39',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/214e9e591f7f7f691f12094475c6a086.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '41d7b5bde89061886316c3733f22a9e6',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/0db53aea8528cf3b6f215f9bdb31791d.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd3c753d23eafc0c02e90670fe0376f8e',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/11ca4246bceb2ccfb52dced183211640.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aed06a921acde2c11ac9b78345d2b796',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/c6bae2eccecc1421d386937c99637b4c.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0e2bc2b38124c73b2e4930422b195f6',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/7f65058ed8cdca87a7e2a1ac3d00fce1.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb863b0a7505c3cb863ed0ab7da84076',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/eb2f0bce6079e875eca8ff1128d26259.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e53dff51506b55510e4141882f778f16',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/a6c3b6ec1645e5160aa2a13fcfabb990.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '29560da4298673b893714b3bb2b0e7bb',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/047880353ca5bd8dce37171d93bc3c5d.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a0b4c9943eefcc482d69b32bf1de30c',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/0bbcec5a7aa047d75f691e622706f74e.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fdb98038ad768a61824150dff8543161',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/24ff6aeb881dfd44443d67b7ab107c39.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd514f98a28f4f9c6bb70886dd0686711',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/7248ab5c62f26de2775e6a42a758f846.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '166f9469b46f820abcd1e8551a5f4345',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/3e66d0df7a1d57ebc0084f5c3c5addf0.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4e484be3f5e704c303ec3112e2056a90',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/365cbe27527ac389ca683670139e9999.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '19831fb97a234afae9824578b713eaad',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/aa932fa63c5c0f93ac8339209554e79e.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b3e4f919f407708ade00a11f1e85a705',
      'native_key' => 'OnBeforeRegisterClientScripts',
      'filename' => 'modEvent/efe0148a53e87369765ffb05f92ce566.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '63bdb8581ec772c60e3e4728f28aa559',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/08be762d8a3887c398d3dde033d0554b.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5568c59fc1517af3174864dadb1b2a41',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/f00bcbb6bcb655efcabee38f89a3ba4a.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5e345a26c276e7423116d9b6ac8b1467',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/214e945a339f5c06d7139ab4d4149dcb.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e9b0fe0cf70ac620e47a9a85cc9da5f6',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/6f2865e469e2c7a1e2509f2341ac54a3.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c786214fbfa3a87b1b69bbcd4b6e4705',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/71d91c35c54f5ee8acada455fbfb7129.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba0e2f858eb520c243cf7bfb8e706bdd',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/a85d6cff2c40c929e276a1525eb661b7.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2e47741bfae2b0f4042cdde070ed78ea',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/99c7d33aa11a1838caf13074238ed67d.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ea17201cc4c6bd38f150a71636390320',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/ead60175b78d70a1ac2811d4abfad1cc.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1193f044acbc03532fc7dbca292346cf',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/a4ece185505b18c2f2bc3cc9c871a70e.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aaaa6fcda1570aa5f4da2b73436ad53f',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/68482fbf05e53cfff6574d109017e0dc.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96354ea24f72449edd6035a1e57e2b4b',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/ed6a55b49b24b4a951c609e44e8b1011.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e2a6e821f5d9ef53a06602475cc1134',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/fd2b6143d501c3a9b50fa1b5ac831fc7.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cdec7444d6e2332b57c2725c45ce07ac',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/2fa9b0e785f26386f10d5d694d5bd48d.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d6b44fe56e4a3630e9947f398cfcc24',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/bf0c0b5fcbc980b4631389df78e0d446.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3e0290a436cfe04f1b2edc133ae2c199',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/9b9976f8b0eb464747d30aefcef0d70e.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'deaedeec7bdf3cee85d28f1b061b8151',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/4c3a90be3438e11834af4d3fe384f592.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eb3f5a7e2961e8ffd0c43df9aa162f9b',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/41b74ff64f23eb108a2911523555a006.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '781bdcd8f9d61c88c3dfe3af0972b399',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/808abcf680ecc60c195c3886dbfe3f81.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f4fa62c547092697ca6f2644de63dc1',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/39fcea222e976da7220712f64fc02ccd.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1bc2e2b52fc5b6541d27bd8cafed1f82',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/77c6231b5cd5debfa025fdfbfca41c5f.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9be76cd9e89fb4102ecefd11c0322c33',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/bfc2b0c3882f51a5f2b6ae26167daafb.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c941f96741fdadd73344bc8524c19c01',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/56d8c53ae972eeef4549befd1b321e23.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ea9ec50d8c56f94d780325124be36d9',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/98b1213bf30e1dc4d581f7d54ef1d657.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5dd984dc3bd3fe384021bcfd8bb47c2a',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/feaeecacdfec2e6b0bc35228497a6561.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5cda3b494bba0d47e9f0f391b2b8cf20',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/8b50a529f4636b6319fbdd9eb0def53d.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ccf3e55d5543ce4eca20ec46cbe20c79',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/863a273c0750fcba18fb35ee725674b1.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bfd3863ac51081e6f779bda6e80d373d',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/730755338f93b69927215e68ee068680.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7daec68ef89bec5e4f46ab849dca57f6',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/2fac0e783bbfac6375c1ce2529cd95ee.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '71fd94d2caa1f78662e01ed13549af35',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/5a381d903ec896211a2540ec9d47f072.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f0dce50615bfe32cc7b6a62e221d0fad',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/a6bd28905b7d66d94343751774045d94.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a93cd1ed9a2ea6ca21507d27224e2bfb',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/9f55516c1e3732b6906dc0f9018fe057.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f082d596308046b0c251e9f7ee28729d',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/e58804fa4f04916f2176fbde13b7e5ae.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '777fe2042ea468a40a751a4a1818f421',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/9b5b87708217826eaf9c4987835cce5a.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '485dbf1d71a1953709f66faf07e4e9fd',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/815e01b377e9c5585f03ea5f9cf388e3.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2b2a6d0459a86c5eabfcaf4b2ba81b09',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/5fdbe17be685a86d992d7fb29cde4377.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd9136e2e1cb0a14b2a65d1cff3f334f1',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/95b52f5c9bb1e1371022ccd58f0493c7.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a1302c83596e321be3b048464f7019f0',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/399dc731d24a4256b52dce2c950300d0.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cd55a9b961a380d40fc1d0262555ce86',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/bc9019cddc06ade581a257f905d4d3c8.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2afaf6cea02229537c60601932fde7f5',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/184b0d0b508626f9f7b8a9558ad871e6.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cd154cbe805f177682472c6b9692a720',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/745d3ab11a069300bbbed47e0a44a4ac.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '37b0ba7eae412a07fccb84c8e139b2ce',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/2feffb045b02433d2cbf501dfb679711.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '45c6b39c28d2fa64d1cc4deac8409101',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/ef94b3d1515129a759302c0b22cdd658.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '35505c8356ca3ad75e3ca624a39da199',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/00d2a5802d72dbb69e93f582422587d5.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dcabc452c5dbc6e83a06a9010014121c',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/d9767ea95501d7a4ff569844d45ac8c0.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9237bd427525298253eb6b43ff51ff5c',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/741b07f5ca9e97228cc602b94d85ea6e.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '66d5dad39379356979273c67128ecbac',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/4aee7f87949080e6bf8443fe53fa7377.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5d9d9c0bac539523ba51b3e97101fa53',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/3596bdebd3d4636faa860fd75ab4ed22.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cd4262a572e2f7f17e95d546b8cb711f',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/cf129e728b63bb12e6c964aa35153c86.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a9f06a210602bd27cd53b79d524d17f9',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/23ba7a4fcd8714771fa5b358958d93da.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a32fab61b756ac6e4a255801581d77ce',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/1d2ae38de6eb3f07e817bf5b21167da0.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a5a2bfcf3693c4609313999759e1c841',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/006e495f0df016b72ead051b1f9493b9.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e0bd47b58415525c19dff98dba9efd2',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/6b7cc67845e6b5ecf19a462846d19529.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'df0e456bc3cddb7174699d750d62533c',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/12a2056fea3c4f2fcf750e359faa7ef3.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '53e6514a769939e92c15783f61205be2',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/b50cddcce40c503921031c176f4dbe79.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5ebe5393badc04fe589a7521a8a21127',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/3500852e3246496aefa5b1dee2d743e1.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9998cac49c2ce9faccce4f056f4e2b6c',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/8522c6b3e476d19dcef720e3e1755639.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '015f382892e6240c151d4ca2b7d69e46',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/ff9210c619239e2bdf6aa6ee404a041e.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7cc39a72b1ed2df96492c2834c4bd283',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/e5dcd9592f0db8578e6ed2b2bc7172e3.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '033e92c24e42bf14dbd8da193a6ec950',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/00567cc3aa54f26e9c6a895fc34df323.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f09f6eba169534b50c66f3ee01a17ea',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/761bca22c676e0015f0f44647c332364.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '25c6f46bee3d7c4229f1b9757ac27b80',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/293c9acfbe62253f27bfc337672d15a5.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd510eae7fe6f938ef05253684a778a25',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/07b5f045f160ddd6efae756afa29bb57.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '62945f9cbc89f3a90498eece99135e2a',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/36eaeac7ae5c429986e325ef33b87454.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd2297968354223004edb379d7b8941a5',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/3f892e723f61095f4ba58ca0df431ed9.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '020e96952cdec5ca8be7e3957b8b640a',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/5f8f1eb88977a17672cb58f32a712113.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c19ab7fd395dbd2500cfddbe798686ef',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/76788dce57a290c24e42b23bb44db7df.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac0517a3c655d13b6723e42043ca0a58',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/4345c3ad436d94cf2fab2df5becd8e71.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6cbe9d81e79af278eb6f2d2947efafe1',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/d3f0a36b7d2536f4960a2dfe42841240.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '889c504a088c706ffde0f927c2db6b87',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/3ba93e22d6c7ead66439c650a520def1.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c8036f33387d823307930487acd7f835',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/8bcf5b24853fe8d86d1a4ac0e14b86bc.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '28e93c2a2d844e710013752218e026f3',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/a732547bbae7cedf8cc2cb6061356c1a.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1892964d1351e1ab3bec6f973231bfaa',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/9ac166cf5cd277cd1f5b4e1e865756c8.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bda564537e7872e266e4ccc6a96922ae',
      'native_key' => 'OnPackageInstall',
      'filename' => 'modEvent/ec398db1a6d2d7d3599c6824ed2a25f4.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '86bf96bff0456d15c5cecfc58edff54f',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'modEvent/e7984567c49b0111159b8e340a1e5b9d.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0390f709bfa6361950c36f328f15c04a',
      'native_key' => 'OnPackageRemove',
      'filename' => 'modEvent/049474eb79b87afd6c243e46030c69e0.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9bc195b02de99dc46c7401beaa38eee7',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/94b538c9a26f042db4722833f5c05ed7.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ab2eeec1148107a31e538b0fa88ec56',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/38c63fbcc065c7e599125059411d0965.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0bbaa245279a303e7610f422916b759',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/45ff75750e7fecef5b16c1a4a5ca9410.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a839274befd0d277fbbcd68f98c5ad8',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/b71fcf503fe92b64cbb015c2e43a57e7.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '492e9c585cce29b22543a87f29ad9615',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/161352539ccdf14f23d26e00a08b5fa2.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5dbe14495c4ec9cb5448f59f4169812',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/97e4abd27f7f0886057f5ae70524655a.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f587836520dab45d2f12337cb9589e41',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/1af4722f421c3d55131c27058024b89e.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f3063eec4f034ebef11ed1aa83e2c9a',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/3cbab01850e90ed2aadbd46cd1d9331c.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04247568c6c7ffdeb79aa3ecbf91863c',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/30357da429cec59a73701b864b89ecb3.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9d2b9989b0ed3e103480a0980c4dcd9',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/0e91b9c646410ab1998cf13c1a1985c4.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '796085f77517ec12654744f594ee356c',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/8256a1b537698f64494f22a76af9f426.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '825c0ff4b70811b4394b583ac0f15874',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/f37a2639cd37637f29e2d8995401c70d.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee84adbbe5cb3a8eb95c0d363f9f8f7b',
      'native_key' => 'automatic_template_assignment',
      'filename' => 'modSystemSetting/d1378f37f06e75e890f6f6412b9a5aae.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80f802deb0f7e7965d3682e9be7fde2c',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/764b259db7d1532c3ece77ca99158b38.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b77bc1167cf7df9ecc588cebf385f992',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/575ce5c69842f45588eb32d9e56e3a82.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4806eef9326ae0a063aa18a2ddc0da57',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/a88fb61fc7772872d1fb5b29b8e27da3.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7875f62449a6ed7eaf6caea9e1fca962',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/6eea1cbc63f010b582ea840d7de4cae1.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29c6827510b7bb5bf84dc6e143ab68da',
      'native_key' => 'use_context_resource_table',
      'filename' => 'modSystemSetting/87fcc6a2eabd56c7147866bc41098251.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c39048399d689716c021663f2c1fb8b',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/10a581c0569d17e125e2e00d54d8af09.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48ec0b924e89d1aa54b3d6c3a8c7794e',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/8c91fd68d14dd7f8f5f2a50467fc0806.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '931346e3322b7325415b22a963917d2e',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/112c91c9d6ffd04d5c73f1711a1c53ff.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bfa5f4231a406f50d1a1c36f283a4914',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/7c397160661f09f01996b2df2873b3f1.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b73955daf9b3a49032acb21dbee2c9d',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/294dacfb1b7e2fb0c7d1e07df30123c4.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc52a2f82f184e5d7206130ec0c87850',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/5a035b30be06501510cdf37edbbf4971.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9195d2e6cd186fb8543fb3ae4e555e11',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/bb62f8e69d0bfa6d1b9f5f3c4035cce4.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21803fc55a5fcd304ccecd5693285901',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/7c3f3243a346d13cdafdd789621ac874.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26b2afcfe6614ef923be88b5284df10b',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/f99ed1c601e7334ab1c56ffad03e382e.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '525c48c8574a3706df5c7edf6f8ad97f',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/a9cba50e55210f821528948da62e80fd.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd86f494bfc5cfa2e4428f00f39be10e',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/79c7a7d4ea0741b0cc20abaff95d639e.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dba40302b1e33fb8f5f8200a11f634ef',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/b58f5e2bddffaf9cd95bf4928880e3ee.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b24ccb53fc42dad09e28ca154a295840',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/7721adaf393fcb44519e816f3ba293d5.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '97a5edae25d4de42c03e6c8b712e672a',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/422cae9b31de5accc1261885c3a349cb.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b835b06e5e43f28b44aabaa70dcc40db',
      'native_key' => 'cache_resource_clear_partial',
      'filename' => 'modSystemSetting/0424b4a2bdf33548630e83d9a2acfe4f.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ddbcd9abff5b02659b36585f894e8410',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/0896a498f58b8f3ab3aea0c0a8e6caf0.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec55bd2dabbe77040868e02cce2f39cf',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/0f58b080d65f30cc240cc780418c6675.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '608f0812d2d58bd39e910b24fcf1b09a',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/286516de35f5226fb149ebb9966b708b.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf51558c584aa08bac716f245dd9f6e0',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/0d166bd7e78ef00bd626af068b839308.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8cba75c5ad02219116e1e157f522f9da',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/6b3ece1a022b0389e7d5381247d0910e.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6b42b97936d5a16ac1f6c4f4176fabb',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/42874541f105350fc20a686ae907990d.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03afec896b84c9d2c0c8652e1e126d52',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/ac0825d58346e686ec4f28e1785b6fce.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b96dabd0b063c15aeee351fcfca7fda',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/8b84c2d7b8e53a062ea062b130775082.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59b26d35312b5456172001c09f931db6',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/5a7ec8f8a5b250ade4e7627991de9bc8.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea798b62800a91e616dee45f21d9ea5c',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/2409e169a8bc64af051b548bd1c2e7f0.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce1ffc1c62e9250f11bf86458a0da218',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/940c42322e6c57916ac3d0afb87d1d8c.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '195b2d80c3a16e63284fb9210d4c2af8',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/73a7999987163cae04b93a1dec9b0b47.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de9cdc1bcbadd421fdc1c22e9c8c24bb',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/143a1dd8d2f7892105ada0cab4b20422.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67f93a68936c9962625ffb03b1bbae7d',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/c6a2897b196b77af87a8c313a777b1fb.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'abbdd9610e98d1097b1c03f666f6f7df',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/358e68728a3330154c07f407c40ea954.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c207f5c98935116894230c1b284d1c08',
      'native_key' => 'default_media_source_type',
      'filename' => 'modSystemSetting/179120fb294dfcd5f62cb551212584a7.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6bb30733ea5369624437b9e81c3d43b4',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/d3e949dfc8e45af5ecec77636ffa31ff.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03c2a6c6e53875b2e02e74fc431592b8',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/2f2fad9a1bacb1a1da5eb10578cce2ab.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c6de70fafd65b50e00e185d8e96b3e4',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/e2d10811355aca490f0049b68634cc71.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d909c8c9662c2261f4f616f2975cc90',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/e80a10b7d45d5b877aff44ced293888c.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a51fc2c38a8e87ace0e0d5e2c7d3090',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/2d93de3fe56bfa96518adf98dca6f2e1.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a6fcaab8af3057324df90a73f0f906c',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/49d17c22ba1029728977820e7c15de7d.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3083ad589e58189c7e64eb3be9f8e446',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/72b1d342422cb8671d7d2a95f3680dff.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81f173425dda8bb3a09db66005e2c712',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/394b896be4dad723e2596ef294bdd930.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '165d46ac4261e2778284e7d21d3090ff',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/cf5f92cb2409d6a209403f605b83f021.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f69df129b48d5fad4210d937168b1f32',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/df0a963ff7fbef47307d91fd5fdbd572.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b97f78091593f2e8eaf2a65796000ed7',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/c8091446603ac18509db502bb9dd2a8a.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6bc7e4c3f5de856bed8c486c56c40bc4',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/fa70c07d4bae490635e01d2f82e7e334.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60d2645edb12fa6539ec05e981cb3a47',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/7b3aeaef63cc9e06cc2f029b6ed7c71a.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '670567402430f781b194ab3bed4fb1da',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/220caeb2a8a47a64e339f9dfb06603a5.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a46d0ad0e52d9d1f6462527a774e5d3',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/e5b18fc5d19c07d9e2ec4258400279a1.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69d1ba9cfcae73139a0e16a0d790eef8',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/a7d585c7c9516bb90b0b336eacdbdbf9.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a1d1fbc502809516938c190f3efd0e8',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/56eea7e59d7daefc8c9ab7f53920a842.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '90b854ef95cf12bae144c30adf01033e',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/7f63cbc2a28c4b5fac9432d678e3704f.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '06b88c4773fc015ed684ba44f60c8a97',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/7615c22b0f1db852e4aa22a8493b9543.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd664ea35ac32c46808826cd296fa03ef',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/23f83a91783aa355db818494cc4b6c59.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88309c35145375efef6da769fed700d3',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/1815ae7bc516fa6f49c97bebb2f704fa.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0dc33d51b9f4923c0f4a79e95e0e7fed',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/5947bab6f42a1d3124d4a75c139f48fc.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e6cc7490dde8e1dc9502a6ce6e1d434f',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/7db20a150c94127403d2138902914af9.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '864a91aeddf785f91628be46b3173a23',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/d009a22a6cafa0fa915e044e3d77e8c3.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6017ce01f59de6d1af29481b0df42d6',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/2c9a1e000266774f7177fe36e40a8dd1.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a7b71ca15a61bfa6f1c214767376471',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/583942d701e8a14897f74dc6f745b6c1.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a9e36de19cb5e30d2927d3979c91e9d',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/0808864a00f6dea0e94ca8bd2d22bb8c.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '22918a1c276c5f03d7b13a156c1367bc',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/142d219795a85a7bc043d520aa6f3635.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81b2f29220ae2fff0b67335b7aa0a279',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/e41c8c061899b2ae79538ed7988bc2e6.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f280d490fb10e109c026041fe2910fec',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/e4ec5e18f1a41160f548aa5bac67f04e.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8dc035f7bebbe92e6207b3a2d14dae13',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/c7b5c9b61f0b3d5956a37d55e0685b4d.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40e6d46fb858d79f59f61dfd2f64d24d',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/9b2d8004b4b8518f6ee58445b30e4af7.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9e15d9a0fa465391c2137b6c955e183',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/130f2d21fe306c07ece87664db2f9449.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '225fb8b03ce36ed03974845380ae2f18',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/2a3abc63d015caf3c89be9d575d14b45.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '257845985efe716f6d083fb77b167721',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/1654e73e824f1fd3b7d41b27f8cd2442.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46f9231d98e0882a3b63623660166198',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/7254654573ff8990a476fa18a3eee848.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ddd47ced2007634c9ee4d98ec04bd69',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/46731a607e0209738e88f0b499ca21e0.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7973e2ccf30f5784a8de087fe66752be',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/497a1ee8864fd4c8fe09096707b9f5f6.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a26e1558729590238ac72f87aa999589',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/3e294061d0e9c0c43470e739efe31eaf.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4db186d63daf82f788f4bfd8c6c02087',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/ecd43e183a9437b02611734a588838c5.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0ea33831ddd1e4c6d25c59d2416d676f',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/e1e2a04be3665042496443ce02193ae7.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0724ad8698a1cf979622462daa39856',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/b753edb2df2b8214fbace2f457bae34e.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'baf7217ab4ab5f01094a03c9a5855601',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/9934598b8129b8c1fa8d0c758595873f.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c30c15b7ffc8113da62321097ce92b0d',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/2b568f2a02d30f26e376c0a9162caca7.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac5606c1c0eaf64f61662ced03eff4e4',
      'native_key' => 'log_deprecated',
      'filename' => 'modSystemSetting/48f8442f334c21d9a7ae22507a95617a.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a725b87622067824195615c8bd41b0f',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/0e110095c85023b9bdcc2a8ef0df4d5e.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '495f84426edd05b2520e8374112e616b',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/38306d276104ccac3caa66b30e207e22.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff66f7ebc31942be603c74c4836d364c',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/fff5c0bb5242930865eaa44f257ce4b2.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f6a3d78012192f515ca6feef82ac7a0',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/b186f9faf94a17c329c70f103b8f9633.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fed7969cc46ddfdc73ae73e9d34991bb',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/c01fec208bc268e320ac3b850d5646c4.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e91aded943cb04c6ff34b259191af1e8',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/0cf11353f2e720615ef11299dc9db9e2.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5f6bed4aad3a7d30741da5c336bf3b7',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/89c9927524d8ec82f640577e7573952f.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e10d63a9d9578dda846ef560c2a10851',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/e7067fcfd821ab7f481a3c26872ef2b1.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'beba448cbe21c613a8d697bbe2b67060',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/9e9bee28e76bef8f28aebaad2da4e193.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1a4c3cfba8eb8b9d5575c2ebc4080fc6',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/40185f634fdf9a1395f13b64f6c04f76.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd666c9706453a42f1a98b9798b8b79fd',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/a47918571fcbf0511c62d195b3d31413.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'af09ae530d66fd88c2c34208968a71b4',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/8aeac8dbd8c59a24eb4f41640d45f12b.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c23314d4c5caec7ed267ef56a8cf66c0',
      'native_key' => 'mail_smtp_autotls',
      'filename' => 'modSystemSetting/c6aa2bc5b35af7042e32cd24229784a5.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c475ce3107978b95bb542715db75b9d1',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/09e70860bd954b1563437fcbb0096a92.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1cb5d61154077c43d9e55cb6dfa40693',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/dada5e323620b890c9eda8c532e411da.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0dab8ece00a9d48f39cf708f274b6414',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/90b4010f135f9f580f100d2db19a9ca9.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '103a620323c23c48540b803805fa0cc4',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/2cda340a04fe1e10ab152dcfdaebd3c2.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '737e2d6ec072ed99bb2f5a17eada1aee',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/6192806b42ebb08982ddf42fb4918730.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0689ba3ec7bf39a19f835694142e670b',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/f06c1c7b036f5cde125b986f0996b0f9.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '232cb72f1fc1bcbf1ece74ca07b04edf',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/e82c59572f915944ddd83673c9cf1456.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35e1454d511cbc4a9ffdd5a5cc6c644b',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/836e7e9511c6e391aac1ae7574051f39.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '075928565332ac73716e2570a3239c51',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/ec06c9d582783c9d64fe5c5bf4cbf91b.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '685b0a1500bfe26dcd97c0fa5d740993',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/021ee9db317ec4ef97b5305436ddf2b6.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd07f3eb6e46e7438930210be81fad4bb',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/af9ce4735b57d0496b2f24e166d01a27.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0570d59831e06371a84d28d197296e60',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/02e7ad549b887b578cebc6a1b0f9aef3.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b3edda34d699cfc4b3a6c8470ef2780',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/73e80248bbba003429185740cb294f28.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c13b9ef6c66da7340433017ef059dfa',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/a2b1c30f883789213606f2b5c263ac8d.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd993fdffcf07dfbf6e102ee1dd3504be',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/5d3982fe1b080fa1d416a355d012f68d.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc7867b731f57ece79448ba49807e709',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/4a6e9c2a50530cd18ddacabfe2a8d43f.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4968235a73e42a09edb0f1c9b24f74bf',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/b27a2fd6c53a8482c67714740a8a90a4.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a740eae3e1e87488ec1c4d308e20f4a',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/cded7da8372f8542ccc6a6f6d0cd8d45.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9fbe2cf2032b21bd3c386a1813d6071',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/6ab3744f91acad23c43abc57751c481f.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a10ac76f94d838fb85c4a3f8bcb16bf5',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/fc7dedc4cc7a89d76167525109aeb042.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd327724ed965cd9ff8b09d45ea3c4dee',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/fbddab3aa32c19dca1d42dc29a4caed8.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc84dd0b4b4a6e1fba69bb36765aed43',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/e3e9d2d0bc3118e81955d805b52a2c81.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '468f9a650872c9b5a5ea52ba10655a5e',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/7f5d2a725d87620c5c71f7dc8c17a797.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f83b4550a0b783d7e255047f1adba957',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/a71419565e8f683d153f737ecb0681cb.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a272fc4a5ced46c7795aa4fa70f62f32',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/4fab9f0f76040756406d8e9e962cc393.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a3b2c322d54f2c2522e672fc8ec8e3f',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/10577139f028de727028ab440a9664bc.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33325d632831c0ceeac086857da233a2',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/3ca030aa0336bb44970b2afa400d7777.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '76a184c748d57d6a410c31ea131d8670',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/f18ffd2e5b34191fc3accf49ab432b62.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c970f58571175915a27afff5b751db18',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/02d85e7cb5c21593acd4332e9d214de4.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e33ca75784bbafc965f1875a29eab1c5',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/2a357ff0275470b1e792b33a1db97c9a.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f7e2ac23abce4409a315e26db5f63e9',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/0ffb6109f025038499844d30f204213c.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a78b2d213d9e0e8a44fa30559e89ac4',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/cc84c3404ff380874226a730dd5119c1.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f77486ad1a2d3c3442b84c31850ba087',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/7e10e37a3fb5c250773a65681e703eee.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb9eec978cd91cf537224dd64933f77d',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/944d10194effaae153df58498edae33b.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cac9506b23b39f8d133d3098fd2c3ca0',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/8d6816063e020d1926534ebe6071e566.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd1345e20588a2b5560edd922d8763b12',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/9af2da7f19e162fa24b11aa404720510.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7537fecd3b3070c276c582d1959b3439',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/f001b6317739e144c5168b8cee777489.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82bc75173ad800104e7d2beeccdc8df8',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/ec527b49023d4afd62280e8c7c33de2d.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '377a80a52d2d34a3bf6d20b0789e6a6d',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/624c9392476f93053cf730b2d9ef9c50.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '884d05691aae3c61489861c22d3f8588',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/e6f3b79db815de26b5bb95289a8cfa16.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '355057f2e7b63fde4672f8339232f2f3',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/27e352fee925cdeeb36f213f506ea7c8.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4cea4af188ad70e554c8451f2ab26f3e',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/6d91f7e44c529aefdc7e1f9a8b58ea2f.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4aee6afbad3597661ee821276df0559',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/d1cf6fc5ddc414fe28075ea1154d7070.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29233976ac17ad710c21bfff65ea91c4',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/d429ab8407f9ae77c6d9346fd60083c2.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3082649c6d405ce2aa2b6e2fdf90fc4',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/092faa0f26d1efd1b5e95cf23ae4210e.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a35baf1c4ccf033c544825b47b26dd52',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/09465b5ebd92d1f73351832aaee17fae.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4377211c0157c509177a438b5b2f16ee',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/4c41c6191aca3eb39ba6c453928bfdfd.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f713e14b0d845167430761bcedd46bc1',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/8b54e51abcf650cb382823de13c8d7b1.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '363362cb0985288b4db54c790c6ed3cf',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/469671fc10d377fdcec50161ced855cc.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53f21c2287ff9ef90af09a3775573a48',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/a63fa98215459e3564c7d2795510d0f1.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e49402697e3bdfec730270fc304fb5a1',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/9470812b9b2db0eafd03f664a26faa8f.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '38d02e2c19dbf264026ed2097adaddea',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/89e2496dd103098e9b3bdf8fb2a4c43d.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2276620d03b87240b5afd25c10a8dd52',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/b8768362263e739fdb1f7dcd3facfc58.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dddb635b867747c7bd6a989bec90f78a',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/f5b3f5d544db23ecbb22703eb49d540d.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf20b6c83b4f81f4063d697b678f76d8',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/4186777b97287756e12d236419825b17.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd6c15d55fa17c8ccc7f1372f54e9ce6',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/589e2e559f90b1a656f7de43faf78f2a.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd7fd5cef9ebc7ab8fb10c076f6f947a',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/a16beb160e459faa22c8ecdb0c2b84d0.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57f072425debd033420775658da5a5fe',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/bb1afc8aa3a6ea8ce96321ba592ddcd8.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '662423d81cbf371d09e859a61e278a01',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/656239d96a52714ed48baee204cb38b0.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd4043b8f93eb5ba8dd7e3aa74d78ea5',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/9e020bef3b0a49383c1c74a22b2f8fc8.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5bbb4033e01c2555baeed29f52dbbd29',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/401584e2f7ae0022029fea9c63767799.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '406b1978d3ef3bb9b553d7fb16542362',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/de62d04948a198f10de5f6c70180625b.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cea55d40819a02b63dba662f2b681cac',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/d66155fd3b65432afecc39c88157054a.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c666e50bee7eb9d3c8f5e429240c043c',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/7232a6627bac12d7144e437bc855172a.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee5dbfa74de3d8250dcb5af0fac83649',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/8a5b12e35f488c6c76ba9ef81003048c.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '511517e856961245936346dcbc5fe0e1',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/89762b52c98052726d56d6232ecc7567.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b69848d5a058c55df27d0376d6476295',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/ff89ff342cb84209bd30c30b0a866d64.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbd5ee8f690ca9eb1d8274601165f752',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/ec17fb19cd2a1a917495fbdf2cc450e9.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3444c3697b16d29fc5220a23e4e7a141',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/5d17a6ae2712fcb4364dddabd2312540.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ec0cd737413e9afae0f19ee4631dc57',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/7e96972cee0c714de0919df4fd743ecc.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df221fe8b9c59517506f18719215f002',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/fe72d141fa0b28528be26f59a674d95c.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f02821a2ff4f7e9e1926ca658cb6f4a9',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/bdbee0e5963648aab03efabebff2f39f.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8a963ba0e1180fcf1ae28b805d48bc4',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/c80b523ab06f75f70f6b7a66f4531cd2.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37acc6a1b9e7051654aecfc5caa054dd',
      'native_key' => 'session_cookie_samesite',
      'filename' => 'modSystemSetting/919c24b499b8280a80c23258f61f7f6c.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4cc2139f6bf54967826cc01205fcf19b',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/f89e84559206cd67312c141fd984f5a5.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4e7123d19a2e827f7f22ff51ac0e701',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/548743a6c72e00dd23119594a799e2b8.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe5658000711c21c11d5150ff8757960',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/cfad44686163513a3e1c2bca5b8b0d82.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ea0a213b4632a45683c194207c20c1c',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/c2eb66e5ca69f139c69c49a5f67a216e.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83c8d7b6526bdbc2910cb36d02d3ddff',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/65e69f4d7ae47eaeda91bbd966ac135b.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71e694f29a72adc2046161ad4a91890f',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/b122977eb0b1e2a4d06974e4ca9d118b.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fab2bf48ad3e45c9369d7016b2100806',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/146bbd48957626fbad99414dc346e83c.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aaf1f1e7caaa7852167c9b99cf208c90',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/54784ddf6cb43994e7ff7768ceec34ba.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63dc62c9f5d2410fe7d60a818b89399b',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/13e242dceae586fe5951ba04020d30c7.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ed098fb550c18069b351f993d25314f3',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/b6d4c8265641f746d070d1c47d92d040.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d8b38304658fb4252e503743571446d',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/6f9e6e52d3154fdaf2745075e6bbd898.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cda3896aa351cc3768ce46c6eab2a01c',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/50b86fed51e92aaba7142432e7be2ebb.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4812d13dd820b5962ec89375ab8f08f',
      'native_key' => 'static_elements_automate_templates',
      'filename' => 'modSystemSetting/db8d088d650dfae5f1983328a809dab1.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f17bdcd1ba35f65718e494f22ec3754',
      'native_key' => 'static_elements_automate_tvs',
      'filename' => 'modSystemSetting/2664d672b1a4f778befc04741b7392f7.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e94ce130f709f3301859704f1ab3c94f',
      'native_key' => 'static_elements_automate_chunks',
      'filename' => 'modSystemSetting/967a2c7fac4362daa606b3443d44df18.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d6ce4c1bb440c8fe7c0c52b5301102c',
      'native_key' => 'static_elements_automate_snippets',
      'filename' => 'modSystemSetting/05251e17939553f34d5e15e27d82cddb.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd3bea4f220bccf15b7c3834d0984cca',
      'native_key' => 'static_elements_automate_plugins',
      'filename' => 'modSystemSetting/efb5dc23af62cb0289d511bd76811261.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8fe92e8cdf02e626ba3c326084314087',
      'native_key' => 'static_elements_default_mediasource',
      'filename' => 'modSystemSetting/a45e8f814f6660d34fd1d567bf4cb8ac.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c13f49da342689fc1402bb8d751f796f',
      'native_key' => 'static_elements_default_category',
      'filename' => 'modSystemSetting/940ac80da9755d08a5df9ed179f60fbc.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b871f64ea19c53c87fcefefa679002aa',
      'native_key' => 'static_elements_basepath',
      'filename' => 'modSystemSetting/c237fe6ba3998224dc308e4b2ef30bf6.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10d35829deb3fe5514fd690db1833074',
      'native_key' => 'resource_static_allow_absolute',
      'filename' => 'modSystemSetting/ca78917d3fe8c7c1286628170c45af47.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5b331e28dff73a1ca2e15b9573b4660',
      'native_key' => 'resource_static_path',
      'filename' => 'modSystemSetting/7115bac4562f034c634ac58835f7a910.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e36822c46244378fff452f749bd8521',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/573ec395f869783a50da2aff0caaecf5.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3560f7fb0fae4a189050b430c35c830',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/9e9c966bdff2923b800c08dc69cb8a65.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'def6031a2fc5c70fe0b38ee3be867f17',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/65fe5e39673c9793afaf5f3a15db5ec5.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '65769007a6f82223486f746cd70dc0b2',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/b6c58dbed82fb91589e988d308dddcf3.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '32d1ad91e501ddee52c69ff6a26aacc7',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/e6302fc5aee54c2047bf5188c4d3ac35.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f0ccd9fc83f90f638c5f45d39a156cc',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/9e3b282f1ea6a5d5be65ae923ea21437.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c0c26e8eb1a298baa9e9c7256940c37',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/1db6e6eb0956f5805b60cbdd43d5472d.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a91d0a677aa7f6742b5da7fa84addf81',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/6276599f9505d53176f09f9918dfbcda.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c2221d31f3f3be3b408d697750bc4cf',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/59291eae7797db0800825d3603aeb5b5.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0fe85978ca30fd1e03bb3fb7a83688d8',
      'native_key' => 'upload_check_exists',
      'filename' => 'modSystemSetting/b1933984ed9c1b8402c4f41e28ca8868.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f5c54b5542118c38cc5f17453ddb65e',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/487b74a3883c2bb53178e0f9877f284e.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4cb199ad99a7ff6df3a0e10b19877270',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/6ef647247bfd2270b31df8f6036442e8.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4e033866cba16d620192c9d85f9e490',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/6308cf10da3dcbeb0d58dc62dbc19f01.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b46a320de99706d443b48ca42fb3d99',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/5a094969cb1bcf8dab3315cbbb18c35b.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e02b62773b3b54b99e0ada897c885980',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/d284fe27487132a7a4944b746d3bb91b.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7f608ee907cfdde77a1aa9c231e14fc',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/9a727ed06b34861fa0fb226629497be6.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7327b5b9452a1f558afefaf957cbcb0b',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/690ebaf3c8aff7828ee8042fb2e6f6cd.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '061139cb9bea3778939eaf2ee8806c8c',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/84418c143936ed18227725d215460193.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10d7e5a3bf06fd5807baae8855f3199d',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/58acb24612f472c5a0f45acea7e2bb52.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c98974c90d2cf77577113eafbfd4de35',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/91a4e9f772a97f15ce3881040109089e.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8010b15f934697fc18903889c6bff042',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/47ce9d8c3304760533a2dd30c80c73ff.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5662405202416fff0bad28da1a4ca063',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/73b9830b7b6020f9a24bd8548f2ed49d.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '283706d0c4fea43ba6c3db41115dae28',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/38addd3611a3e508d8820803482d938b.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c70757ab720b20b60b5eee5703af3d02',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/c05f46bd6bb694597a674caf04847a48.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b4c80cb7ceb9a8fd81263483485ca97',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/36370a6a5c7be3e695c95a14aafe1dd7.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0484d593ee43de0c3ede2342dae78ba4',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/fa9a4e0b61d3875f0e7420147370ec2c.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbf51fc1e5988f7ed8e413312bd84b36',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/13e35649b75b3a16a2dce00eed9c2ce8.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9af29893ce6ad10e520ece89c4142dd2',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/d31ac0b6f4985d00601df1ee3822bc21.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd08da24f98e26939b7428027e660235c',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/cc733bf80f59d39d8451cb7d55558957.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16aa0ddcb7a4e82d96e8a33fa9ee65ed',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/4a1c4dd4033cdd97111fdaf7dff482bc.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea7625a18d723f7e17e9be5772c700dd',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/a8a79a7b2bee2702a223ebce44b726aa.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0734d9f6689477ac98a5334e6efd4c00',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/6ad31118cedd765a74f6028dc94a69ba.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6efeb87afd0a7ff9043583551f22a4a',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/825045f5938e071768cc1087a720875e.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '649d309ab78d7f423a53bd4047e2d1e8',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/a32923fc10bce301aa66d383aa1f114e.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab5bed5c9d864465181ab75d7dbef6b9',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/11a3e0d96930d67f057f72ab51fbb6a8.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8bb22e8ef2641d773e8fd00ab83f4ecc',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/98b80d4d34d04e404357a879e29049eb.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96ebed5ff06f16e92321ffc6bb1c586b',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/46b6b504f5c94bbd3dd488b2c16f2e74.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9c25140bdc55b2804d2814dd09154f7',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/179c5fb4b1101ea0ddcb8c10d2d6d34f.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '682a3d964fb3b3e95ed2f18aae26e638',
      'native_key' => 'allow_tv_eval',
      'filename' => 'modSystemSetting/6876db1dd774a6f7e4a1c120883358ef.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd83bd79bd5e5ce18824cfad03b775f7',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'modSystemSetting/a71bff76dedac1199af4155640ce7338.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8fb282656c6c9ff8a8d3c14c5ae1e340',
      'native_key' => 'error_log_filename',
      'filename' => 'modSystemSetting/d40e7766ef0f2bbafe6fb1ee728b0bee.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5dbb47f5f188bb46620a7affd1502140',
      'native_key' => 'error_log_filepath',
      'filename' => 'modSystemSetting/7665249acdc26a805229efc5690badb5.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'aeb78e4bd1052302d3c5f5b51d32e8aa',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/d15eba47f60467f53fef9edc712a70de.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '6d646e22a09b6c3f009dcb853f8fa0cf',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/6c652996829566311d0de1a99b95aa22.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '352922fb362b6bf698f94fdb780e3138',
      'native_key' => 1,
      'filename' => 'modUserGroup/cf7f51d94cbf116f9e71de217f023207.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => 'e4ca73ca8e19f76b92ed2d943236e08e',
      'native_key' => 1,
      'filename' => 'modDashboard/401bdc8ce5731dcd001f7bf540f754b1.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => 'd63c56398bb9c2590f2ef05edb5f1695',
      'native_key' => 1,
      'filename' => 'modMediaSource/682f0c0ba84051f7b6407db021a24b4a.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '978a00de03ec51293f75c325a4a8c61d',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/ee1b9403ccee5e1a0ffbd9ed34daf51c.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'adf46ec74eea5152568326760f5a11e7',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/d7764b0f2f9d1665d048409d3d89e502.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '03fed49baa6750d695cc6f729f59b5c7',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/7580bfcf9baa6d48bbede59028e9f9d0.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '1fd71eab5de60f66d352a38fbfa2bfaf',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/be045b51a0bb1e89c5c1e076a50d9810.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'a057bdadfa19381be6bbfcf7026e9bd0',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/52bcf1fc24f6d4cbbb2b58d788fc9b2e.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'd23ba0235662f3663d7538255bd1f3a3',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/1541cd9a16a7a86d5bca4ca934d2a9b0.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'bf615a47463a71b8c0d0fa2f2978003d',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/2c1b546d85485d5f283ed562080fc070.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'ab427b40eb84148b25f692057b586b4d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/3b5ce5920cc1d46465c446bb1ee1a758.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '731e71915186b42b93a702d6d383de47',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/252ceec285498d7a986f87d9f3520fec.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '9857014bd3c3a4cdd9f7d9ab78fda496',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/bf29b5d941bc4d508ab2e05a60a78007.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '0a9f7b41895f06642b89896224c95cfe',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/3658670a2835008719d804503b66cce5.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '1234689c18f30580a77feef7ddf97a9c',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/60c7879a15830c4971a72b9f4415c521.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '23919d8a0443100e4cbbe3282af77d39',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/2ef50ca3173f65f34b07a91769350dbd.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '54288be7e711f1ba3f0047553e06a7d7',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/812af4c326b8b237cb9fb60863e96a57.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '3ad53298906a19ca609377e284847bdd',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/2a8cfbca317ab0d2c2d1c5b8241a6aa7.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'cae5e53f0287707a4605faf234e3f029',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/b698685dca4f31dbc730c49245c86046.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '5d6e3d3baf4f74f2e1723d70fb75d24f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/d1fbb9b81393ac6fb0f48fcf43514ebd.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'dcca2abba1950b0dec97b6b084a591a3',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/1e4bfb6c3709947c568a1ac69a66fb01.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'ed8219f7c5b61a161d2fdc01724ec9ef',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/48197ddc3b9ee02f74eb0d6fd0e3d2ea.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '2b1c8556211220c4394e201a1d467cf3',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/8d228b919318be665b98f01425b900bb.vehicle',
    ),
    482 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '0a26414d9f41c593fd515dacf66ef9ac',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/d82ebff05676491657e43b31bb97387e.vehicle',
    ),
    483 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '78fe35e6a32f0e8a7d4c7d1424f8c83c',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/5283d3e949bdc87e7da0a491ac47d372.vehicle',
    ),
    484 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '5f29d035d2a2164efefa850dff644dd1',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/5a7283e426242884d363de37951a2238.vehicle',
    ),
    485 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'ce70bbf998f288ace4025be96e778c29',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/ca20a8dc0e441aacc631b0ccad81f0a5.vehicle',
    ),
    486 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd3ae7b0cdc8c5b4568e216515ed309b3',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/cc6e845496a2a18973c82bcb398712c9.vehicle',
    ),
    487 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'cb68824b66a83ef0185b4ad5e82329a6',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/bc7a1040af68aeee44d8f729523ff417.vehicle',
    ),
    488 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '51fb00983bd9cbacda18b81a0d6d7d73',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/56743b7aadaec3e2e338f85755edb3d2.vehicle',
    ),
    489 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'b3bfe7d2e36bdd9262fe2961355a3afd',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/5e05b215158d1805f756a197d5dff97a.vehicle',
    ),
    490 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '8cd8ea6543fe20caef11d33bb96781e8',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/927ab1e311d17d3b3b6f85ee84f13636.vehicle',
    ),
    491 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '35ebb6b0709ae6afb2725fe15952e286',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/aaa735612ce52f9ceee29d5610eae228.vehicle',
    ),
    492 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a201d2ddf4900251428d81a127fad002',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/7fad93cc2e80661e1d9576cdd7aa5fd8.vehicle',
    ),
    493 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '9a154c5977abc1a4e946e386208e4a63',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/df44adaff4f2c0e0d26bd7976c83355e.vehicle',
    ),
    494 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '598f114f662e9de698f8fefd0a190bcc',
      'native_key' => 'web',
      'filename' => 'modContext/0f9a011eeb56224ca37a9d03118e6955.vehicle',
    ),
    495 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '8ec717e717d81d2c3839faf2df85f3da',
      'native_key' => 'mgr',
      'filename' => 'modContext/a6cffbdaced1141d0a5b8c1fed7c399d.vehicle',
    ),
    496 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'b537e772273717301a26425e239626a1',
      'native_key' => 'b537e772273717301a26425e239626a1',
      'filename' => 'xPDOFileVehicle/c41020f829c232a99ac9547fd296d40e.vehicle',
    ),
    497 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '9cd1ffc9d09f31ab59a1a3cc0bfbe585',
      'native_key' => '9cd1ffc9d09f31ab59a1a3cc0bfbe585',
      'filename' => 'xPDOFileVehicle/e3f41b2403516b4e0f240d00c6b7a672.vehicle',
    ),
    498 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '7d7b9bd52d9ab2beb03337c1e5ce077a',
      'native_key' => '7d7b9bd52d9ab2beb03337c1e5ce077a',
      'filename' => 'xPDOFileVehicle/7c75e4c83769866da5b56bc4e3d63a2b.vehicle',
    ),
    499 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '1b388a6fd7110103862f6e8dcd3afa3b',
      'native_key' => '1b388a6fd7110103862f6e8dcd3afa3b',
      'filename' => 'xPDOFileVehicle/e07b91411eefcd30d0f5f8ade0c542ba.vehicle',
    ),
  ),
);